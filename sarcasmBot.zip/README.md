# SarcasmBot
SarcasmBot tells you where the sarcasm is at. 

Developed using [this](https://github.com/yagop/node-telegram-bot-api) cool package!

This is also my first Node app so yay!
